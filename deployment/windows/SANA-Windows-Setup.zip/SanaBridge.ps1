param(
    [ValidateSet('inspect-wsdl','prepare-contract','check-contract','init-db','serve','status')]
    [string]$Action = 'check-contract',
    [string]$Root = 'C:\SanaCrmBridge',
    [string]$SubmissionId = ''
)

$ErrorActionPreference = 'Stop'
$AppDirectory = Join-Path $Root 'app'
$PythonExecutable = Join-Path $AppDirectory '.venv\Scripts\python.exe'
$SettingsFile = Join-Path $Root 'private\server-env.json'
$AllowedNames = @(
    'PAYAMGOSTAR_WSDL_URL','PAYAMGOSTAR_ENDPOINT','PAYAMGOSTAR_USERNAME',
    'PAYAMGOSTAR_PASSWORD','PAYAMGOSTAR_CONTRACT_FILE','PAYAMGOSTAR_ALLOW_HTTP',
    'PAYAMGOSTAR_SEARCH_QUERY_TEMPLATE','PAYAMGOSTAR_SEARCH_TYPE_KEY',
    'PAYAMGOSTAR_SEARCH_QUERY_VERIFIED','SANA_DB_PATH','SANA_WEBHOOK_URL',
    'SANA_ALLOWED_ORIGIN','SANA_INGEST_TOKEN','SANA_BIND','PORT'
)

if (-not (Test-Path -LiteralPath $PythonExecutable)) {
    throw 'Python virtual environment is missing. Create app\.venv first.'
}
if (-not (Test-Path -LiteralPath $SettingsFile)) {
    throw 'Private server-env.json is missing.'
}
$Settings = Get-Content -LiteralPath $SettingsFile -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($Property in $Settings.PSObject.Properties) {
    if ($AllowedNames -notcontains $Property.Name -or $Property.Value -isnot [string]) {
        throw 'Unexpected setting name or value type in private configuration.'
    }
    [Environment]::SetEnvironmentVariable($Property.Name, $Property.Value, 'Process')
}
if ($Action -eq 'init-db' -and (Test-Path -LiteralPath $Settings.SANA_DB_PATH)) {
    throw 'Database already exists. Never reset or replace it during deployment.'
}
$CommandArguments = @('-m', 'services.payamgostar', $Action)
if ($Action -eq 'status') {
    if (-not $SubmissionId) { throw 'Supply -SubmissionId for status.' }
    $CommandArguments += @('--submission-id', $SubmissionId)
}
Push-Location -LiteralPath $AppDirectory
try {
    & $PythonExecutable @CommandArguments
    $ServiceExitCode = $LASTEXITCODE
} finally {
    Pop-Location
}
exit $ServiceExitCode
