# نصب سرویس سانا روی Windows Server پیام‌گستر

این راهنما نصب را توضیح می‌دهد؛ هنوز روی سرور واقعی شما اجرا نشده است. UI سایت و workflow فعلی n8n تغییر نمی‌کنند. فرمان‌های inspect-wsdl، prepare-contract و check-contract هیچ رکورد CRM ایجاد نمی‌کنند. serve، پردازشگر ارسال واقعی است؛ فقط پس از آماده‌شدن تنظیمات و بررسی راه‌اندازی شود. دیتابیس تازه خالی است و تا دریافت لید، رکوردی برای ارسال ندارد.

## ۱. فایل‌ها و Python

Python 3.12 نسخهٔ ۶۴بیتی را از python.org روی سرور نصب کنید. سرویس با Python 3.12 در CI تست شده است. وجود Python را در PowerShell بررسی کنید:

```powershell
py -3.12 --version
```

کد branch feature/sana-payamgostar-soap مخزن زیر را از GitHub دانلود کنید:

https://github.com/mo90mosleh/SanaDeviceLanding/tree/feature/sana-payamgostar-soap

ساختار پوشه‌ها چنین باشد؛ services مستقیماً داخل app باشد، نه داخل یک پوشهٔ ZIP دیگر:

```text
C:\SanaCrmBridge\
  SanaBridge.ps1
  app\services\payamgostar\...
  private\server-env.json
  data\
```

app فقط کد و محیط Python است. private و data خارج app هستند و هنگام تعویض نسخه نباید پاک یا بازنویسی شوند. این پوشه‌ها را در ریشهٔ عمومی IIS یا داخل پوشهٔ برنامهٔ CRM قرار ندهید.

## ۲. پوشه‌های دائمی و دسترسی

PowerShell را با Run as administrator باز کنید و اجرا کنید:

```powershell
New-Item -ItemType Directory -Force C:\SanaCrmBridge\app,C:\SanaCrmBridge\private,C:\SanaCrmBridge\data
icacls C:\SanaCrmBridge\private /inheritance:r /grant:r '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F'
icacls C:\SanaCrmBridge\data /inheritance:r /grant:r '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-18:(OI)(CI)F'
```

این ACL برای Administrators و SYSTEM است؛ حساب Task Scheduler پیشنهادی SYSTEM است. اگر IT از حساب اختصاصی سرویس استفاده کند، فقط همان حساب باید مجوز خواندن private و نوشتن data بگیرد. مسیر data روی دیسک محلی و دائمی باشد؛ NFS/پوشهٔ اشتراکی مناسب نیست. از DB با روش سازگار SQLite پشتیبان بگیرید و marker آن را هم حفظ کنید.

## ۳. تنظیمات خصوصی

فایل server-env.example.json را به این مسیر کپی کنید و نام آن را server-env.json بگذارید:

```text
C:\SanaCrmBridge\private\server-env.json
```

فقط روی خود سرور PAYAMGOSTAR_USERNAME و PAYAMGOSTAR_PASSWORD را وارد کنید. فایل پرشده را در GitHub، چت، پوشهٔ عمومی IIS یا ZIP گزارش قرار ندهید. اگر رمز شامل کوتیشن یا backslash است، قواعد escape رشتهٔ JSON را رعایت کنید. سایر تنظیمات نمونه از مسیر موجود پروژه گرفته شده‌اند؛ انتخابگر CBCSalesOpp و query از PDF رسمی Form تأیید شده‌اند. کلید SANA_INGEST_TOKEN می‌تواند خالی بماند؛ برای replay سروری اختیاری است و نباید در مرورگر قرار بگیرد.

ابتدا WSDL نمونه را از داخل همان Windows Server در مرورگر باز کنید:

http://79.127.121.10:8090/Services/API/IForm.svc?wsdl

اگر روی سرور در دسترس نیست، راه‌اندازی قرارداد هنوز ممکن نیست؛ متن خطا را بدون اطلاعات ورود گزارش کنید. IP عمومی ممکن است از داخل شبکه به تنظیم NAT loopback وابسته باشد. این وضعیت به معنی خرابی CRM نیست. برای انتخاب آدرس داخلی باید آدرس importهای WSDL/XSD نیز با آن سازگار باشد؛ آداپتور import از مبدأ متفاوت را عمداً رد می‌کند. سایت و binding فعلی CRM را برای حل این موضوع خودسرانه عوض نکنید.

فایل SanaBridge.ps1 را در C:\SanaCrmBridge قرار دهید. این فایل تنظیمات JSON را در env همان process بارگذاری می‌کند؛ رمز در آرگومان خط فرمان قرار نمی‌گیرد و فایل JSON خودکار به وب ارسال نمی‌شود.

## ۴. نصب وابستگی و بررسی بدون ثبت رکورد

بعد از قرارگرفتن کد در app:

```powershell
Set-Location C:\SanaCrmBridge\app
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r services\payamgostar\requirements.txt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SanaCrmBridge\SanaBridge.ps1 -Action inspect-wsdl
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SanaCrmBridge\SanaBridge.ps1 -Action prepare-contract
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SanaCrmBridge\SanaBridge.ps1 -Action check-contract
```

prepare-contract فقط یک‌بار فایل private\form-contract.json را می‌سازد؛ فایل موجود را بازنویسی نمی‌کند. در deployهای بعدی همین فایل حفظ شود. اگر قرارداد واقعی عوض شد، ابتدا تفاوتش بررسی شود؛ برای رفع خطا فایل قرارداد را بدون بررسی حذف نکنید. تغییر بایت‌های WSDL/XSD باعث رد fingerprint قبلی خواهد شد.

این بررسی‌ها فقط GET metadata و serialization محلی‌اند؛ حتی موفقیتشان صحت رمز و مجوز ثبت حساب را ثابت نمی‌کند. هیچ‌کدام SaveForm یا SearchForm واقعی را فراخوانی نمی‌کنند. آزمایش ثبت واقعی هنوز به اجازهٔ جداگانهٔ مالک نیاز دارد.

## ۵. ایجاد یک‌بارهٔ صف و اجرای محلی

پس از موفقیت مرحلهٔ قبل، init-db را فقط یک بار روی دیسک دائمی اجرا کنید:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SanaCrmBridge\SanaBridge.ps1 -Action init-db
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SanaCrmBridge\SanaBridge.ps1 -Action serve
```

پنجرهٔ serve باز می‌ماند. در PowerShell دیگری بررسی کنید:

```powershell
Invoke-RestMethod http://127.0.0.1:8081/healthz
```

status=ready یعنی پذیرش HTTP آماده است؛ channels.crm و channels.webhook باید running باشند. blocked یعنی آماده‌سازی آن کانال ناموفق بوده است و کانال دیگر می‌تواند مستقل ادامه دهد. پس از اصلاح تنظیمات، سرویس را restart کنید. running به معنی تأیید مجوز ثبت زنده نیست. تا زمانی که فرم‌های سایت به gateway متصل نشده‌اند، کاربر فعلی همچنان مستقیم به n8n ارسال می‌کند.

اگر DB قبلاً موجود است init-db را تکرار نکنید. outbox.sqlite، فایل‌های WAL همراه و outbox.sqlite.instance را برای تعویض نسخه یا reset شمارنده پاک نکنید. در صورت port conflict، ابتدا برنامهٔ اشغال‌کنندهٔ 8081 شناسایی شود؛ پورت CRM را تغییر ندهید.

## ۶. مسیر HTTPS عمومی

برای کاربران بیرون شبکه، یک hostname مانند leads.ortanes.com با DNS و گواهی معتبر لازم است. این فقط نام پیشنهادی است و هنوز تنظیم نشده است. DNS و NAT باید به ورودی HTTPS سرور برسند. آدرس cbc.ortanes.com همچنان روی GitHub Pages بماند.

روی IIS یک سایت/hostname جدا ایجاد کنید. با URL Rewrite + ARR (در صورت نصب و مجازبودن در سازمان)، فقط مسیر زیر reverse proxy شود:

```text
https://HOSTNAME/api/leads → http://127.0.0.1:8081/api/leads
```

Origin و Content-Type باید عبور کنند و OPTIONS و POST برای /api/leads مجاز باشند. محدودیت اندازهٔ درخواست، timeout و rate limit روی reverse proxy تنظیم شود. سرویس Python روی 127.0.0.1 بماند؛ برای آن ورودی عمومی 8081 یا سرویس SOAP تازه باز نکنید. private/data/app از IIS قابل دانلود نباشند. تنظیمات سایت CRM فعلی تغییر نکند. اگر تنظیم DNS، NAT یا گواهی دست شما نیست، این بخش را مسئول شبکه انجام دهد؛ صرف دسترسی ادمین Windows برای دسترسی کاربران بیرون شرکت کافی نیست.

## ۷. اجرای خودکار پس از reboot

پس از پایان تست محلی، اجرای دستی serve را با Ctrl+C ببندید. در Task Scheduler یک Task ایجاد کنید:

- Trigger: At startup، با تأخیر حدود ۳۰ ثانیه.
- Account: SYSTEM، Run with highest privileges؛ تنظیمات ACL مرحلهٔ ۲ با همین حساب هماهنگ‌اند.
- Program: powershell.exe
- Arguments:

```text
-NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\SanaCrmBridge\SanaBridge.ps1 -Action serve
```

- Start in: C:\SanaCrmBridge\app
- در صورت شکست process، restart فعال باشد.
- محدودیت توقف پس از چند ساعت غیرفعال باشد.
- If already running: Do not start a new instance.

Task را Run کنید و /healthz را دوباره بررسی کنید. آماده‌سازی یک کانال بعد از چهار خطا متوقف می‌شود ولی process زنده می‌ماند؛ پس بعد از اصلاح تنظیمات یک کانال blocked، Task را restart کنید. از reset دیتابیس برای رفع خطای اتصال استفاده نکنید.

## ۸. اتصال سایت، آخرین مرحله

وقتی hostname عمومی و HTTPS آماده شد، آدرس /api/leads و نتیجهٔ healthz بدون رمز/فایل خصوصی را گزارش کنید. تنظیمات build سایت بعداً روی branch بررسی‌شده تغییر می‌کنند:

```dotenv
VITE_CONSULTATION_SERVER_MODE=true
VITE_CONSULTATION_API_URL=https://HOSTNAME/api/leads
```

این دو مقدار عمومی‌اند. آدرس SOAP و credentialها فقط در server-env.json/env سرور می‌مانند. UI و n8n تغییر نمی‌کنند. از این پس هر لید ابتدا در صف دائمی ثبت و در دو کانال مستقل به webhook قبلی و SaveForm فرستاده می‌شود. پیش از تأیید نهایی این مرحله، تنظیم production سایت را عوض نکنید.
